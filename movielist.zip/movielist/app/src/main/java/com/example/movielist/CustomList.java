package com.example.movielist;

public class CustomList
{
    private int mimageid;
    private String mmoviename, mmoviedescription;
    public  CustomList(int imgid, String movien, String mmovied)
    {
        mimageid=imgid;
        mmoviename=movien;
        mmoviedescription=mmovied;
    }


    public int getMimageid() {
        return mimageid;
    }

    public String getMmoviename() {
        return mmoviename;
    }

    public String getMmoviedescription() {
        return mmoviedescription;
    }
}

package com.example.movielist;

public class CustomList
{
    private int mimageid;
    private String mmoviename, mmoviedescription, mmovierating;
    public  CustomList(int imgid, String movien, String mmovied, String movier)
    {
        mimageid=imgid;
        mmoviename=movien;
        mmovierating=movier;

        mmoviedescription=mmovied;


    }

    public String getMmovierating() {
        return mmovierating;
    }

    public int getMimageid() {
        return mimageid;
    }

    public String getMmoviename() {
        return mmoviename;
    }

    public String getMmoviedescription() {
        return mmoviedescription;
    }
}


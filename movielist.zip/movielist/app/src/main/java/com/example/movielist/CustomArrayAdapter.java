package com.example.movielist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class CustomArrayAdapter extends ArrayAdapter<CustomList> {
    public CustomArrayAdapter(@NonNull Context context, int resource, @NonNull ArrayList<CustomList> CustomLists) {
        super(context, resource, CustomLists);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {



        View listitemview= convertView;
        if(listitemview==null)
        {
            listitemview= LayoutInflater.from(getContext()).inflate(R.layout.custom_list, parent, false);
            CustomList currentitem= getItem(position);
            ImageView imageview=listitemview.findViewById(R.id.img);
            imageview.setImageResource(currentitem.getMimageid());
            TextView textview1=listitemview.findViewById(R.id.movies_name);
            textview1.setText(currentitem.getMmoviename());
            TextView textview3=listitemview.findViewById(R.id.movie_rating);
            textview3.setText(currentitem.getMmovierating());
            TextView textview2=listitemview.findViewById(R.id.movie_description);
            textview2.setText(currentitem.getMmoviedescription());
            return listitemview;
        }



        return super.getView(position, convertView, parent);
    }
}

package com.example.movielist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView main_listview=findViewById(R.id.main_listview);
        ArrayList <CustomList> movieslist= new ArrayList<>();

        movieslist.add(new CustomList(R.drawable.panga, "PANGA","HINDI MOVIE"));
        movieslist.add(new CustomList(R.drawable.baaghi, "BAAGHI","HINDI MOVIE"));
        movieslist.add(new CustomList(R.drawable.war, "WAR","HINDI MOVIE"));
        movieslist.add(new CustomList(R.drawable.houseful, "HOUSEFULL","HINDI MOVIE"));
        movieslist.add(new CustomList(R.drawable.zero, "ZERO","HINDI MOVIE"));
        CustomArrayAdapter arrayAdapter=new CustomArrayAdapter(this, 0,movieslist);
        main_listview.setAdapter(arrayAdapter);
    }
}
